README

Steps to run the code:
1. Navigate to the file in path code/extract_features.py
2. Run the command "python extract_features.py"

Required python modules:
pip
numpy
pandas
tsfresh
matplotlib
sklearn

Additional Files:
- All the output screenshots are present in graphs folder.
